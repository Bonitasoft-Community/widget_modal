(function () {
  try {
    return angular.module('bonitasoft.ui.widgets');
  } catch(e) {
    return angular.module('bonitasoft.ui.widgets', []);
  }
})().directive('customModalButton', function() {
    return {
      controllerAs: 'ctrl',
      controller: /**
 * The controller is a JavaScript function that augments the AngularJS scope and exposes functions that can be used in the custom widget template
 * 
 * Custom widget properties defined on the right can be used as variables in a controller with $scope.properties
 * To use AngularJS standard services, you must declare them in the main function arguments.
 * 
 * You can leave the controller empty if you do not need it.
 */
function ($scope, $element) {
   
    
    // add a new variable in AngularJS scope. It'll be usable in the template directly with {{ backgroudColor }} 
    this.isShowModal = false;
    
    this.init = function() {
        var source_elements = document.getElementsByClassName( $scope.properties.cssContainerId );
        var targetmodal_element = document.getElementById( $scope.properties.cssContainerId+"_modal");
   
        if (! source_elements || source_elements.length === 0  )
        {
            alert("No element with class ["+$scope.properties.cssContainerId+"]");
            return;
        }
      
        targetmodal_element.appendChild( source_elements[ 0 ] );

    }
    
    var vm=this;
    
     angular.element(document).ready(function () {
       vm.init();
    });
    
    this.openModal = function() {
        this.isShowModal = true;

    }
    this.closeModal = function () {
}

},
      template: '<!-- The custom widget template is defined here\n   - You can use standard HTML tags and AngularJS built-in directives, scope and interpolation system\n   - Custom widget properties defined on the right can be used as variables in a templates with properties.newProperty\n   - Functions exposed in the controller can be used with ctrl.newFunction()\n   - You can use the \'environment\' property injected in the scope when inside the Editor whiteboard. It allows to define a mockup\n     of the Custom Widget to be displayed in the whiteboard only. By default the widget is represented by an auto-generated icon\n     and its name (See the <span> below).\n-->\n \n<span ng-if="environment"><identicon name="{{environment.component.id}}" size="30" background-color="[255,255,255, 0]" foreground-color="[51,51,51]"></identicon> {{environment.component.name}}</span>\n\n<modal-dialog show=\'ctrl.isShowModal\' dialog-title=\'{{properties.modalTitle}}\' width=\'75%\' height=\'80%\' 	close="action.closeModal()"> \n	<div class="modal-content" width=\'100%\' height=\'100%\' id="{{properties.cssContainerId}}_modal">\n	</div>\n</modal-dialog>\n \n<div class="text-{{ properties.alignment }}">\n    <button\n        ng-class="\'btn btn-\' + properties.buttonStyle"\n        ng-click="ctrl.openModal()"\n        type="button"\n        ng-disabled="properties.disabled || ctrl.busy" ng-bind-html="properties.label | uiTranslate"></button>\n</div>\n'
    };
  });
